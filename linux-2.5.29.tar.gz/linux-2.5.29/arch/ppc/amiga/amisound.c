/*
 * BK Id: SCCS/s.amisound.c 1.5 05/17/01 18:14:20 cort
 */
#include "../../m68k/amiga/amisound.c"
