/*
 * BK Id: SCCS/s.amiga_ksyms.c 1.5 05/17/01 18:14:20 cort
 */
#include "../../m68k/amiga/amiga_ksyms.c"
