/*
 * BK Id: SCCS/s.chipram.c 1.7 05/21/01 00:49:49 cort
 */
#include "../../m68k/amiga/chipram.c"
