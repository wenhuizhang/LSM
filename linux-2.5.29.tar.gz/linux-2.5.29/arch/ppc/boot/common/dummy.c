/*
 * BK Id: %F% %I% %G% %U% %#%
 */
int main(void)
{
	return 0;
}
