#ifndef __MATROXFB_G450_H__
#define __MATROXFB_G450_H__

#include <linux/ioctl.h>
#include "matroxfb_base.h"

struct matroxfb_g450_info {
	struct matrox_fb_info*	primary_dev;
	unsigned int		timmings;
};

#endif /* __MATROXFB_MAVEN_H__ */
