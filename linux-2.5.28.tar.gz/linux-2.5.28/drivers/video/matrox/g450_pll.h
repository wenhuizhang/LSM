#ifndef __G450_PLL_H__
#define __G450_PLL_H__

#include "matroxfb_base.h"

int matroxfb_g450_setclk(WPMINFO unsigned int fout, unsigned int pll);

#endif	/* __G450_PLL_H__ */
